import test from 'node:test';
import assert from 'node:assert/strict';
import health from './netlify/functions/health.mjs';
import story from './netlify/functions/story-generate.mjs';
import image from './netlify/functions/image-generate.mjs';
import veoStart from './netlify/functions/veo-start.mjs';
import veoStatus from './netlify/functions/veo-status.mjs';
import veoDownload from './netlify/functions/veo-download.mjs';
import trends from './netlify/functions/trend-radar.mjs';

const request = (url, method = 'GET', body, extraHeaders = {}) => new Request(`https://example.test${url}`, { method, headers: { 'content-type': 'application/json', ...extraHeaders }, ...(body !== undefined ? { body: JSON.stringify(body) } : {}) });

test('health responds without revealing secrets', async () => {
  const saved = process.env.STUDIO_ACCESS_CODE; delete process.env.STUDIO_ACCESS_CODE;
  try {
    const response = await health(request('/.netlify/functions/health'));
    assert.equal(response.status, 200);
    const data = await response.json();
    assert.equal(typeof data.geminiKeyPresent, 'boolean');
    assert.equal(typeof data.youtubeKeyPresent, 'boolean');
    assert.equal('key' in data, false);
  } finally { if (saved !== undefined) process.env.STUDIO_ACCESS_CODE = saved; }
});

test('configured shared access code blocks API calls without the code', async () => {
  const savedCode = process.env.STUDIO_ACCESS_CODE; const savedKey = process.env.GEMINI_API_KEY;
  process.env.STUDIO_ACCESS_CODE = 'test-shared-code'; delete process.env.GEMINI_API_KEY;
  try {
    const blocked = await story(request('/story-generate', 'POST', { idea: 'funny cat', sceneCount: 3 }));
    assert.equal(blocked.status, 401);
    const allowed = await story(request('/story-generate', 'POST', { idea: 'funny cat', sceneCount: 3 }, { 'x-studio-access-code': 'test-shared-code' }));
    assert.equal(allowed.status, 503);
    assert.match((await allowed.json()).error, /GEMINI_API_KEY/);
  } finally {
    if (savedCode !== undefined) process.env.STUDIO_ACCESS_CODE = savedCode; else delete process.env.STUDIO_ACCESS_CODE;
    if (savedKey !== undefined) process.env.GEMINI_API_KEY = savedKey; else delete process.env.GEMINI_API_KEY;
  }
});

test('story generation rejects non-POST methods', async () => {
  const response = await story(request('/story-generate', 'GET'));
  assert.equal(response.status, 405);
});

test('story generation explains missing key', async () => {
  const saved = process.env.GEMINI_API_KEY; delete process.env.GEMINI_API_KEY;
  try {
    const response = await story(request('/story-generate', 'POST', { idea: 'a funny cat', sceneCount: 3 }));
    assert.equal(response.status, 503);
    assert.match((await response.json()).error, /GEMINI_API_KEY/);
  } finally { if (saved !== undefined) process.env.GEMINI_API_KEY = saved; }
});

test('image endpoint gives a truthful missing-key message', async () => {
  const saved = process.env.GEMINI_API_KEY; delete process.env.GEMINI_API_KEY;
  try {
    const response = await image(request('/image-generate', 'POST', { prompt: 'cartoon' }));
    assert.equal(response.status, 503);
  } finally { if (saved !== undefined) process.env.GEMINI_API_KEY = saved; }
});

test('video start gives a truthful missing-key message', async () => {
  const saved = process.env.GEMINI_API_KEY; delete process.env.GEMINI_API_KEY;
  try {
    const response = await veoStart(request('/veo-start', 'POST', { prompt: 'funny cartoon' }));
    assert.equal(response.status, 503);
  } finally { if (saved !== undefined) process.env.GEMINI_API_KEY = saved; }
});

test('video status validates operation identifiers', async () => {
  const saved = process.env.GEMINI_API_KEY; process.env.GEMINI_API_KEY = 'test-only';
  try {
    const response = await veoStatus(request('/veo-status?operation=not-valid'));
    assert.equal(response.status, 400);
  } finally { if (saved !== undefined) process.env.GEMINI_API_KEY = saved; else delete process.env.GEMINI_API_KEY; }
});

test('video download rejects untrusted origins', async () => {
  const saved = process.env.GEMINI_API_KEY; process.env.GEMINI_API_KEY = 'test-only';
  try {
    const response = await veoDownload(request('/veo-download?uri=https%3A%2F%2Fevil.example%2Fmedia.mp4'));
    assert.equal(response.status, 400);
  } finally { if (saved !== undefined) process.env.GEMINI_API_KEY = saved; else delete process.env.GEMINI_API_KEY; }
});

test('trend radar explains missing YouTube key', async () => {
  const saved = process.env.YOUTUBE_API_KEY; delete process.env.YOUTUBE_API_KEY;
  try {
    const response = await trends(request('/trend-radar?q=funny'));
    assert.equal(response.status, 503);
    assert.match((await response.json()).error, /YOUTUBE_API_KEY/);
  } finally { if (saved !== undefined) process.env.YOUTUBE_API_KEY = saved; }
});
