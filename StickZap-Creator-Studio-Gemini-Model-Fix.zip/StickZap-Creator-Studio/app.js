'use strict';

const $ = (id) => document.getElementById(id);
const FUNCTION_ROOT = '/.netlify/functions';
const DB_NAME = 'stickzap-creator-studio';
const DB_VERSION = 1;
const VIEWS = {
  home: ['Make your next short.', 'YOUR CREATIVE WORKSPACE'],
  trends: ['Find a fresh idea.', 'TREND DISCOVERY'],
  story: ['Build a story that lands.', 'STORY WORKSHOP'],
  direct: ['Generate a video clip.', 'DIRECT VIDEO'],
  frames: ['Shape every scene.', 'FRAME-TO-FRAME STUDIO'],
  export: ['Save it. Render it. Share it.', 'PROJECTS & EXPORT'],
  help: ['Make the connections work.', 'SETUP & HELP']
};
const state = { db: null, project: null, projects: [], busy: false, directBlob: null, directBlobUrl: null, directOperation: '', toastTimer: null, frameBatchBusy: false, renderBlob: null, renderUrl: null };
const blobUrls = new WeakMap();

function uid() { return `p_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`; }
function safeText(value) { return String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function escapeAttribute(value) { return safeText(value).replace(/\n/g, ' '); }
function toast(message, kind = '') {
  const el = $('toast'); if (!el) return;
  el.textContent = message; el.className = `toast show${kind ? ` ${kind}` : ''}`;
  clearTimeout(state.toastTimer); state.toastTimer = setTimeout(() => el.classList.remove('show'), 4500);
}
function setInlineStatus(id, message, isError = false) {
  const el = $(id); if (!el) return; el.textContent = message; el.style.color = isError ? 'var(--orange)' : '';
}
function setButtonBusy(buttonId, busy, busyText = 'Working…') {
  const el = $(buttonId); if (!el) return;
  if (busy && !el.dataset.originalText) el.dataset.originalText = el.textContent;
  el.disabled = busy;
  el.textContent = busy ? busyText : (el.dataset.originalText || el.textContent);
  if (!busy) delete el.dataset.originalText;
}
function delay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
function apiHeaders(jsonBody = false) {
  const headers = {}; if (jsonBody) headers['content-type'] = 'application/json';
  try { const code = sessionStorage.getItem('stickzap-access-code'); if (code) headers['x-studio-access-code'] = code; } catch {}
  return headers;
}

function makeProject(name = 'Untitled funny short') {
  return {
    id: uid(), name, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
    idea: '', title: name, hook: '', summary: '', script: '', genre: 'Funny daily life', audience: 'General audience',
    language: 'English', storyLength: 'medium', visualStyle: 'StickZap 2D cartoon', sceneCount: 5,
    characterLock: 'Light-gray rounded body, huge half-lidded eyes, wide mischievous toothy grin, thin black arms, long legs, black cargo shorts, black-and-white sneakers, backward black cap with StickZap logo. Preserve these proportions.',
    frameRatio: '9:16', videoRatio: '9:16', scenes: [], caption: '', hashtags: '#FunnyShorts #CartoonComedy #Shorts #StickZap', directBlob: null
  };
}

function openDB() {
  return new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) return reject(new Error('IndexedDB not available'));
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains('projects')) db.createObjectStore('projects', { keyPath: 'id' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Cannot open local project database'));
  });
}
function dbRequest(mode, operation) {
  return new Promise((resolve, reject) => {
    const tx = state.db.transaction('projects', mode);
    const store = tx.objectStore('projects');
    let req;
    try { req = operation(store); } catch (e) { reject(e); return; }
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error('Project database error'));
  });
}
function projectForStorage(project) {
  const copy = structuredClone(project);
  copy.scenes = (copy.scenes || []).map(scene => { delete scene.clipUrl; return scene; });
  delete copy.directBlobUrl;
  return copy;
}
function hydrateProject(project) {
  const copy = projectForStorage(project);
  copy.scenes = (copy.scenes || []).map(scene => ({ ...scene, clipUrl: scene.clipBlob ? objectUrl(scene.clipBlob) : '' }));
  return copy;
}
function objectUrl(blob) {
  if (!(blob instanceof Blob)) return '';
  let url = blobUrls.get(blob); if (!url) { url = URL.createObjectURL(blob); blobUrls.set(blob, url); }
  return url;
}
async function allProjects() {
  if (state.db) return (await dbRequest('readonly', store => store.getAll())).sort((a, b) => Date.parse(b.updatedAt || 0) - Date.parse(a.updatedAt || 0));
  try { return JSON.parse(localStorage.getItem('stickzap-projects') || '[]'); } catch { return []; }
}
async function persistProject(project = state.project, quiet = false) {
  if (!project) return;
  project.updatedAt = new Date().toISOString();
  try {
    if (state.db) await dbRequest('readwrite', store => store.put(projectForStorage(project)));
    else {
      const minimal = projectForStorage(project);
      minimal.scenes = minimal.scenes.map(s => ({ ...s, clipBlob: null })); minimal.directBlob = null;
      const list = JSON.parse(localStorage.getItem('stickzap-projects') || '[]').filter(p => p.id !== minimal.id);
      list.push(minimal); localStorage.setItem('stickzap-projects', JSON.stringify(list));
    }
    state.projects = await allProjects();
    $('save-status').innerHTML = '<span class="status-pip"></span> Saved locally';
    $('home-project-title').textContent = project.title || project.name;
    $('home-project-summary').textContent = project.summary || (project.idea ? project.idea.slice(0, 110) : 'Start a story to populate your storyboard and create clips.');
    $('stat-scenes').textContent = (project.scenes || []).length;
    $('stat-frames').textContent = (project.scenes || []).reduce((n, s) => n + Number(Boolean(s.startFrame)) + Number(Boolean(s.endFrame)), 0);
    $('stat-clips').textContent = (project.scenes || []).filter(s => s.clipBlob).length + Number(Boolean(project.directBlob));
    if (!quiet) renderProjectList();
  } catch (error) {
    $('save-status').textContent = 'Save failed';
    if (!quiet) toast(`Could not save this project on the device: ${error.message}`, 'error');
  }
}
let saveTimer;
function scheduleSave() { clearTimeout(saveTimer); $('save-status').textContent = 'Saving…'; saveTimer = setTimeout(() => persistProject(state.project, true), 350); }

function setView(name) {
  if (!VIEWS[name]) name = 'home';
  document.querySelectorAll('.view').forEach(el => el.classList.toggle('active', el.id === `view-${name}`));
  document.querySelectorAll('.nav-item[data-view]').forEach(el => el.classList.toggle('active', el.dataset.view === name));
  $('page-title').textContent = VIEWS[name][0]; $('top-eyebrow').textContent = VIEWS[name][1];
  $('sidebar').classList.remove('open');
  if (name === 'frames') renderScenes();
  if (name === 'export') renderProjectList();
  if (name === 'home') updateHomeStats();
  history.replaceState(null, '', `#${name}`);
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
function updateHomeStats() {
  const p = state.project; if (!p) return;
  $('home-project-title').textContent = p.title || p.name;
  $('home-project-summary').textContent = p.summary || (p.idea ? p.idea.slice(0, 110) : 'Start a story to populate your storyboard and create clips.');
  $('stat-scenes').textContent = (p.scenes || []).length;
  $('stat-frames').textContent = (p.scenes || []).reduce((n, s) => n + Number(Boolean(s.startFrame)) + Number(Boolean(s.endFrame)), 0);
  $('stat-clips').textContent = (p.scenes || []).filter(s => s.clipBlob).length + Number(Boolean(p.directBlob));
}
function updateInputsFromProject() {
  const p = state.project; if (!p) return;
  $('story-idea').value = p.idea || '';
  $('story-genre').value = p.genre || 'Funny daily life'; $('story-audience').value = p.audience || 'General audience';
  $('story-language').value = p.language || 'English'; $('story-length').value = p.storyLength || 'medium';
  $('scene-count').value = String(p.sceneCount || 5); $('visual-style').value = p.visualStyle || 'StickZap 2D cartoon';
  $('character-lock').value = p.characterLock || '';
  $('frame-ratio').value = p.frameRatio || '9:16'; $('direct-ratio').value = p.videoRatio || '9:16';
  $('story-char-count').textContent = `${($('story-idea').value || '').length} / 6000`;
  $('current-story-title').textContent = p.title || 'Your story is waiting';
  $('current-story-hook').textContent = p.hook || p.summary || 'Your generated hook and story summary will appear here.';
  $('use-story-direct').disabled = !p.script && !p.idea;
  $('open-frame-studio').disabled = !(p.scenes || []).length;
  $('frame-story-name').textContent = p.title || 'No story selected';
  $('frame-story-summary').textContent = p.summary || 'Generate a story first to create editable scene cards.';
  $('social-caption').value = p.caption || p.hook || '';
  $('social-tags').value = p.hashtags || '#FunnyShorts #CartoonComedy #Shorts #StickZap';
  if (p.directBlob instanceof Blob) {
    state.directBlob = p.directBlob; state.directBlobUrl = objectUrl(p.directBlob);
    $('direct-stage').innerHTML = `<video controls playsinline preload="metadata" src="${escapeAttribute(state.directBlobUrl)}"></video>`;
    $('direct-download').href = state.directBlobUrl; $('direct-download').hidden = false; $('direct-to-export').disabled = false;
  } else if ($('direct-stage')) {
    $('direct-stage').innerHTML = '<div class="stage-placeholder"><div class="play-orb">▶</div><strong>Nothing generated yet</strong><small>Your preview appears here after the provider returns a result.</small></div>';
    $('direct-download').hidden = true; $('direct-to-export').disabled = true;
  }
  renderScenes(); updateHomeStats();
}
function syncInputsToProject() {
  const p = state.project; if (!p) return;
  p.idea = $('story-idea').value.trim(); p.genre = $('story-genre').value; p.audience = $('story-audience').value;
  p.language = $('story-language').value; p.storyLength = $('story-length').value; p.sceneCount = Number($('scene-count').value) || 5;
  p.visualStyle = $('visual-style').value; p.characterLock = $('character-lock').value.trim(); p.frameRatio = $('frame-ratio').value;
  p.videoRatio = $('direct-ratio').value; p.caption = $('social-caption').value; p.hashtags = $('social-tags').value;
  $('story-char-count').textContent = `${$('story-idea').value.length} / 6000`;
}
function normalizeScene(scene, index, project) {
  return {
    id: scene.id || `sc_${index + 1}_${uid().slice(-4)}`,
    title: String(scene.title || `Scene ${index + 1}`), action: String(scene.action || scene.description || ''),
    dialogue: String(scene.dialogue || ''), voiceover: String(scene.voiceover || ''),
    imagePrompt: String(scene.imagePrompt || `${project.visualStyle || 'StickZap 2D cartoon'}. Scene action: ${scene.action || ''}. Character: ${project.characterLock || 'expressive cartoon character'}.`),
    videoPrompt: String(scene.videoPrompt || `${project.visualStyle || 'StickZap 2D cartoon'}. ${scene.action || ''} ${scene.dialogue || ''}`),
    startFrame: scene.startFrame || '', endFrame: scene.endFrame || '', clipBlob: scene.clipBlob instanceof Blob ? scene.clipBlob : null,
    clipUrl: scene.clipBlob instanceof Blob ? objectUrl(scene.clipBlob) : '', duration: Number(scene.duration) || 8
  };
}
function localStoryDraft(source = 'idea') {
  syncInputsToProject(); const p = state.project;
  const raw = (source === 'script' ? (p.script || p.idea) : p.idea) || 'A lazy cartoon hero tries to avoid one tiny chore, but every shortcut creates a bigger problem and the final shortcut backfires in a silly way.';
  const sentences = raw.replace(/\n+/g, ' ').split(/(?<=[.!?])\s+/).filter(Boolean);
  const count = p.sceneCount || 5; const sceneNouns = ['The setup', 'A bad idea', 'Things get worse', 'The big mistake', 'The twist', 'The reveal', 'Unexpected trouble', 'The payoff', 'One last surprise', 'The final gag', 'The consequence', 'The punchline'];
  const hook = sentences[0]?.slice(0, 140) || 'One tiny shortcut turns into a ridiculous problem.';
  const scenes = Array.from({ length: count }, (_, i) => {
    const start = Math.floor(i * sentences.length / count); const end = Math.max(start + 1, Math.floor((i + 1) * sentences.length / count));
    const bit = sentences.length ? sentences.slice(start, end).join(' ') : raw;
    const beats = i === 0 ? `Open with a clear visual hook. ${bit}` : i === count - 1 ? `Deliver a visual punchline and a quick reaction. ${bit}` : `${i % 2 ? 'Escalate the misunderstanding' : 'Show the consequence'} using clear exaggerated physical comedy. ${bit}`;
    return normalizeScene({ title: `${String(i + 1).padStart(2, '0')} · ${sceneNouns[i % sceneNouns.length]}`, action: beats,
      dialogue: i === 0 ? 'Hero: “This will be easy.”' : i === count - 1 ? 'Hero: “That was not part of the plan!”' : '',
      voiceover: '', imagePrompt: `${p.visualStyle}. ${p.characterLock}. ${beats}. Clear silhouette, comedy staging, ${p.frameRatio} composition, no text or watermark.`,
      videoPrompt: `${p.visualStyle}. ${p.characterLock}. Animate this scene: ${beats}. Expressive poses, readable timing, squash-and-stretch movement, crisp hand-drawn outlines.` }, i, p);
  });
  return { title: makeTitle(raw), hook, summary: `A ${p.genre.toLowerCase()} short for ${p.audience.toLowerCase()}. ${raw.slice(0, 190)}`, script: raw, scenes };
}
function makeTitle(text) {
  const first = String(text || '').replace(/\s+/g, ' ').replace(/[.!?].*$/g, '').trim();
  if (!first) return 'The Unexpected Twist';
  return first.length > 44 ? `${first.slice(0, 41).trim()}…` : first;
}
async function generateStory(useAI = true) {
  syncInputsToProject(); const p = state.project;
  if (!p.idea && useAI) { toast('Write a story idea first, or use Quick local outline.', 'error'); $('story-idea').focus(); return; }
  if (!useAI) {
    applyStoryResult(localStoryDraft('idea'), 'Local outline created. This did not call an AI service.');
    return;
  }
  setButtonBusy('generate-story', true, '✦ Writing…'); setInlineStatus('story-status', 'Writing the story and planning scenes with Gemini…');
  try {
    const response = await fetch(`${FUNCTION_ROOT}/story-generate`, { method: 'POST', headers: apiHeaders(true), body: JSON.stringify({ idea: p.idea, genre: p.genre, audience: p.audience, language: p.language, length: p.storyLength, style: p.visualStyle, characterLock: p.characterLock, sceneCount: p.sceneCount }) });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Story generation request failed (${response.status}).`);
    applyStoryResult(data, `AI story created with ${Math.min(p.sceneCount, (data.scenes || []).length)} planned scene(s). Review everything before generating media.`);
    toast('Story and scenes generated. Review the storyboard next.');
  } catch (error) {
    setInlineStatus('story-status', `${error.message} Use “Quick local outline” for a local draft, or check Setup & help.`, true);
    toast(error.message, 'error');
  } finally { setButtonBusy('generate-story', false); }
}
function applyStoryResult(data, status) {
  const p = state.project;
  p.title = String(data.title || makeTitle(p.idea)); p.name = p.title; p.hook = String(data.hook || data.logline || '');
  p.summary = String(data.summary || ''); p.script = String(data.script || data.story || p.idea);
  const rawScenes = Array.isArray(data.scenes) ? data.scenes : [];
  p.scenes = rawScenes.slice(0, Math.min(Math.max(1, p.sceneCount || 5), 12)).map((s, i) => normalizeScene(s, i, p));
  while (p.scenes.length < (p.sceneCount || 5)) p.scenes.push(normalizeScene({ title: `Scene ${p.scenes.length + 1}`, action: 'Continue the story with a clear visual beat.', imagePrompt: `${p.visualStyle}. ${p.characterLock}. Continue the story: ${p.summary}` }, p.scenes.length, p));
  p.caption = p.hook || p.title;
  $('current-story-title').textContent = p.title; $('current-story-hook').textContent = p.hook || p.summary;
  $('use-story-direct').disabled = false; $('open-frame-studio').disabled = false;
  $('frame-story-name').textContent = p.title; $('frame-story-summary').textContent = p.summary;
  $('home-project-title').textContent = p.title; $('home-project-summary').textContent = p.summary;
  setInlineStatus('story-status', status); renderScenes(); updateHomeStats(); persistProject(p, true);
}

function renderScenes() {
  const list = $('scene-list'); if (!list || !state.project) return;
  const scenes = state.project.scenes || [];
  $('scenes-empty').hidden = scenes.length > 0;
  if (!scenes.length) { list.innerHTML = ''; return; }
  list.innerHTML = scenes.map((scene, index) => {
    const start = scene.startFrame ? `<img src="${escapeAttribute(scene.startFrame)}" alt="Start frame for ${escapeAttribute(scene.title)}">` : `<div class="frame-placeholder"><span>▧</span><small>No start frame generated</small></div>`;
    const end = scene.endFrame ? `<img src="${escapeAttribute(scene.endFrame)}" alt="End frame for ${escapeAttribute(scene.title)}">` : `<div class="frame-placeholder"><span>◈</span><small>No end frame generated</small></div>`;
    const clip = scene.clipBlob ? `<div class="scene-preview-video"><video controls playsinline preload="metadata" src="${escapeAttribute(scene.clipUrl || objectUrl(scene.clipBlob))}"></video><p class="result-caption">Generated clip saved in this project.</p></div>` : '';
    return `<article class="scene-card" data-scene-card="${index}">
      <div class="scene-header"><div class="scene-number"><span class="scene-count">${String(index + 1).padStart(2, '0')}</span><input aria-label="Scene ${index + 1} title" class="scene-title-field" data-scene-title="${index}" value="${escapeAttribute(scene.title)}"></div><span class="scene-duration">${scene.duration || 8}s target</span></div>
      <div class="scene-edit-grid"><div class="form-field"><label>Action / visual beat</label><textarea rows="3" data-scene-field="action" data-scene="${index}">${safeText(scene.action)}</textarea></div><div class="form-field"><label>Dialogue</label><textarea rows="3" data-scene-field="dialogue" data-scene="${index}" placeholder="Optional character dialogue">${safeText(scene.dialogue)}</textarea></div><div class="form-field"><label>Image prompt</label><textarea rows="3" data-scene-field="imagePrompt" data-scene="${index}">${safeText(scene.imagePrompt)}</textarea></div><div class="form-field"><label>Video motion prompt</label><textarea rows="3" data-scene-field="videoPrompt" data-scene="${index}">${safeText(scene.videoPrompt)}</textarea></div></div>
      <div class="scene-frames"><div class="frame-box"><div class="frame-preview">${start}</div><div class="frame-info"><strong>Start frame</strong><button class="btn btn-secondary" data-action="start-frame" data-scene="${index}">✦ ${scene.startFrame ? 'Regenerate' : 'Generate frame'}</button></div></div><div class="frame-box"><div class="frame-preview">${end}</div><div class="frame-info"><strong>End frame</strong><button class="btn btn-secondary" data-action="end-frame" data-scene="${index}">✦ ${scene.endFrame ? 'Regenerate' : 'Generate frame'}</button></div></div></div>
      <div class="scene-footer"><button class="btn btn-primary" data-action="animate-scene" data-scene="${index}" ${scene.startFrame && scene.endFrame ? '' : 'disabled'}>▶ Animate scene</button><button class="btn btn-secondary" data-action="download-frame" data-scene="${index}" data-frame="start" ${scene.startFrame ? '' : 'disabled'}>⇩ Start image</button><button class="btn btn-secondary" data-action="download-frame" data-scene="${index}" data-frame="end" ${scene.endFrame ? '' : 'disabled'}>⇩ End image</button><button class="btn btn-secondary" data-action="download-clip" data-scene="${index}" ${scene.clipBlob ? '' : 'disabled'}>⇩ MP4 clip</button></div>${clip}
    </article>`;
  }).join('');
}

async function resizeImageData(dataUrl, maxEdge = 1200, quality = 0.82) {
  return new Promise((resolve, reject) => {
    const image = new Image(); image.onload = () => {
      const scale = Math.min(1, maxEdge / Math.max(image.naturalWidth, image.naturalHeight));
      const canvas = document.createElement('canvas'); canvas.width = Math.max(1, Math.round(image.naturalWidth * scale)); canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
      const ctx = canvas.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height); ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
      resolve(canvas.toDataURL('image/jpeg', quality));
    }; image.onerror = () => reject(new Error('Could not read the generated frame image.')); image.src = dataUrl;
  });
}
function ratioLabel(ratio) { return ratio === '1:1' ? 'square 1:1' : ratio === '16:9' ? 'landscape 16:9' : 'portrait 9:16'; }
async function generateFrame(index, frameType, quiet = false) {
  const p = state.project; const scene = p?.scenes?.[index]; if (!scene) throw new Error('Scene not found.');
  const button = document.querySelector(`[data-action="${frameType}-frame"][data-scene="${index}"]`);
  if (button) { button.disabled = true; button.textContent = 'Generating…'; }
  if (!quiet) setInlineStatus('story-status', `Generating ${frameType === 'start' ? 'start' : 'end'} frame for scene ${index + 1}…`);
  try {
    const frameExtra = frameType === 'start' ? 'Opening composition: the character is clearly visible before the main action starts.' : 'Closing composition: capture the final pose/reaction after the scene action. Maintain the exact same character design.';
    const prompt = `${scene.imagePrompt}\n\n${p.characterLock ? `Character consistency lock: ${p.characterLock}.` : ''}\n${frameExtra}\nVisual style: ${p.visualStyle}. Composition ratio: ${ratioLabel($('frame-ratio').value)}. No watermark, no captions, clean readable silhouette.`;
    const response = await fetch(`${FUNCTION_ROOT}/image-generate`, { method: 'POST', headers: apiHeaders(true), body: JSON.stringify({ prompt, style: p.visualStyle, ratio: ratioLabel($('frame-ratio').value) }) });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Image generation failed (${response.status}).`);
    const dataUrl = await resizeImageData(`data:${data.mimeType || 'image/png'};base64,${data.imageData}`);
    if (frameType === 'start') scene.startFrame = dataUrl; else scene.endFrame = dataUrl;
    p.frameRatio = $('frame-ratio').value;
    await persistProject(p, true); renderScenes(); updateHomeStats();
    if (!quiet) toast(`Scene ${index + 1} ${frameType} frame is ready.`);
    return dataUrl;
  } catch (error) {
    if (!quiet) toast(error.message, 'error'); throw error;
  } finally {
    if (button && button.isConnected) { button.disabled = false; button.textContent = `✦ ${frameType === 'start' ? (scene.startFrame ? 'Regenerate' : 'Generate frame') : (scene.endFrame ? 'Regenerate' : 'Generate frame')}`; }
  }
}
async function startVideoJob({ prompt, aspectRatio = '9:16', durationSeconds = '8', resolution = '720p', firstFrame = '', lastFrame = '', onProgress = () => {} }) {
  const body = { prompt, aspectRatio, durationSeconds: String(durationSeconds), resolution };
  if (firstFrame) body.firstFrame = firstFrame;
  if (lastFrame) body.lastFrame = lastFrame;
  const response = await fetch(`${FUNCTION_ROOT}/veo-start`, { method: 'POST', headers: apiHeaders(true), body: JSON.stringify(body) });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Video request failed (${response.status}).`);
  const operation = data.operationName;
  if (!operation) throw new Error('Video provider did not return a generation operation.');
  for (let attempt = 0; attempt < 90; attempt++) {
    onProgress(Math.min(91, 8 + attempt), attempt + 1);
    await delay(8000);
    const checkResponse = await fetch(`${FUNCTION_ROOT}/veo-status?operation=${encodeURIComponent(operation)}`, { headers: apiHeaders() });
    const status = await checkResponse.json().catch(() => ({}));
    if (!checkResponse.ok) throw new Error(status.error || `Status check failed (${checkResponse.status}).`);
    if (!status.done) continue;
    if (status.state !== 'completed' || !status.videoUri) throw new Error(status.error || 'Video generation ended without a downloadable clip.');
    onProgress(96, 'Downloading the generated clip…');
    const downloadUrl = `${FUNCTION_ROOT}/veo-download?uri=${encodeURIComponent(status.videoUri)}`;
    const downloadResponse = await fetch(downloadUrl, { headers: apiHeaders() });
    if (!downloadResponse.ok) {
      const errorText = await downloadResponse.text().catch(() => '');
      throw new Error(errorText || `Video download failed (${downloadResponse.status}).`);
    }
    return await downloadResponse.blob();
  }
  throw new Error('Video generation is still running after 12 minutes. You can try again later; this operation may continue at the provider.');
}
async function animateScene(index) {
  const p = state.project, scene = p?.scenes?.[index]; if (!scene) return;
  if (!scene.startFrame || !scene.endFrame) { toast('Generate both start and end frames first.', 'error'); return; }
  if (scene.startFrame.length > 3_000_000 || scene.endFrame.length > 3_000_000) {
    scene.startFrame = await resizeImageData(scene.startFrame, 900, 0.72); scene.endFrame = await resizeImageData(scene.endFrame, 900, 0.72);
  }
  try {
    toast(`Animating scene ${index + 1}. This can take several minutes.`);
    const ratio = $('frame-ratio').value === '16:9' ? '16:9' : '9:16';
    const blob = await startVideoJob({ prompt: `${scene.videoPrompt}\nKeep visual continuity between the supplied first and last frames. ${p.characterLock}. Do not add captions or logos.`, aspectRatio: ratio, durationSeconds: '8', resolution: '720p', firstFrame: scene.startFrame, lastFrame: scene.endFrame,
      onProgress: (n, attempt) => { setInlineStatus('story-status', typeof attempt === 'number' ? `Animating scene ${index + 1}: waiting for provider (check ${attempt}/90)…` : `Animating scene ${index + 1}: ${attempt}`); } });
    scene.clipBlob = blob; scene.clipUrl = objectUrl(blob); scene.duration = 8;
    await persistProject(p, true); renderScenes(); updateHomeStats(); toast(`Scene ${index + 1} video is ready and saved locally.`); return true;
  } catch (error) { toast(error.message, 'error'); setInlineStatus('story-status', error.message, true); return false; }
}
async function generateAllFrames() {
  const p = state.project; if (!p?.scenes?.length) { toast('Generate a story first.', 'error'); return; }
  if (state.frameBatchBusy) return;
  const missing = p.scenes.reduce((n, s) => n + Number(!s.startFrame) + Number(!s.endFrame), 0);
  if (!missing) { toast('All scene frames already exist.'); return; }
  if (!confirm(`Generate ${missing} missing frame image(s)? AI image generation may use provider credits.`)) return;
  state.frameBatchBusy = true; setButtonBusy('generate-all-frames', true, 'Generating frames…');
  try {
    for (let i = 0; i < p.scenes.length; i++) {
      for (const type of ['start', 'end']) if (!p.scenes[i][`${type}Frame`]) {
        $('generate-all-frames').textContent = `Scene ${i + 1}/${p.scenes.length}…`;
        await generateFrame(i, type, true);
        await persistProject(p, true);
      }
    }
    renderScenes(); toast('All requested scene frames are generated. Review them, then animate scenes one by one.');
  } catch (error) { toast(`Frame batch stopped: ${error.message}`, 'error'); }
  finally { state.frameBatchBusy = false; setButtonBusy('generate-all-frames', false); }
}

async function generateFullAnimation() {
  const p = state.project;
  if (!p?.scenes?.length) { toast('Generate a story first.', 'error'); return; }
  if (state.frameBatchBusy) return;
  const missingFrames = p.scenes.reduce((n, s) => n + Number(!s.startFrame) + Number(!s.endFrame), 0);
  const missingClips = p.scenes.filter(s => !s.clipBlob).length;
  const jobs = missingFrames + missingClips;
  if (!jobs) { toast('All scene frames and clips are already ready.'); setView('export'); return; }
  const estimate = `${missingFrames} image frame(s) and ${missingClips} video clip(s)`;
  if (!confirm(`Automatically generate the full storyboard? This will request ${estimate}. It can take a long time and may use paid API credits. Continue only if your provider account has permission and you accept any applicable charges.`)) return;
  state.frameBatchBusy = true;
  setButtonBusy('generate-full-animation', true, 'Working…');
  const button = $('generate-full-animation');
  try {
    for (let i = 0; i < p.scenes.length; i++) {
      for (const type of ['start', 'end']) {
        if (!p.scenes[i][`${type}Frame`]) {
          button.textContent = `Frames · scene ${i + 1}/${p.scenes.length}`;
          await generateFrame(i, type, true); await persistProject(p, true);
        }
      }
    }
    renderScenes();
    for (let i = 0; i < p.scenes.length; i++) {
      if (!p.scenes[i].clipBlob) {
        button.textContent = `Video · scene ${i + 1}/${p.scenes.length}`;
        const succeeded = await animateScene(i);
        if (!succeeded) throw new Error(`Stopped at scene ${i + 1}. Fix the error, then tap Auto-generate scenes again; completed scenes will be kept.`);
      }
    }
    await persistProject(p, true); renderScenes(); updateHomeStats();
    toast('Every scene has a generated clip. Open Projects & export to render the final sequence.');
    setView('export');
  } catch (error) { toast(error.message, 'error'); setInlineStatus('story-status', error.message, true); }
  finally { state.frameBatchBusy = false; setButtonBusy('generate-full-animation', false); }
}

async function generateDirectVideo() {
  syncInputsToProject(); const prompt = $('direct-prompt').value.trim();
  if (!prompt) { toast('Enter a video prompt or import your story first.', 'error'); return; }
  $('direct-stage').innerHTML = '<div class="stage-placeholder"><div class="play-orb">…</div><strong>Generating your clip</strong><small>This may take a few minutes. Keep this tab open.</small></div>';
  $('direct-download').hidden = true; $('direct-progress-wrap').hidden = false; $('direct-pulse').classList.add('busy');
  setButtonBusy('generate-direct', true, 'Submitting…'); setInlineStatus('direct-status', 'Submitting to the video provider. Check model availability and billing if the request fails.');
  try {
    const blob = await startVideoJob({ prompt: `${state.project.visualStyle}. ${state.project.characterLock ? `Character lock: ${state.project.characterLock}.` : ''} ${prompt}`, aspectRatio: $('direct-ratio').value, durationSeconds: $('direct-duration').value, resolution: $('direct-resolution').value,
      onProgress: (n, attempt) => { $('direct-progress').style.width = `${Math.min(100, n)}%`; $('direct-progress-label').textContent = typeof attempt === 'number' ? `Waiting for generation result · check ${attempt}/90` : attempt; } });
    state.project.directBlob = blob; state.directBlob = blob; state.directBlobUrl = objectUrl(blob);
    $('direct-stage').innerHTML = `<video controls playsinline preload="metadata" src="${escapeAttribute(state.directBlobUrl)}"></video>`;
    $('direct-download').href = state.directBlobUrl; $('direct-download').download = 'stickzap-direct-clip.mp4'; $('direct-download').hidden = false;
    $('direct-progress').style.width = '100%'; $('direct-progress-label').textContent = 'Completed · saved in the current project';
    $('direct-to-export').disabled = false;
    await persistProject(state.project, true); updateHomeStats(); setInlineStatus('direct-status', 'The direct clip is ready. Download the clip or add it to the frame timeline.'); toast('Direct video generated and saved locally.');
  } catch (error) {
    $('direct-stage').innerHTML = `<div class="stage-placeholder"><div class="play-orb">!</div><strong>Generation did not complete</strong><small>${safeText(error.message)}</small></div>`;
    setInlineStatus('direct-status', error.message, true); toast(error.message, 'error');
  } finally { setButtonBusy('generate-direct', false); $('direct-pulse').classList.remove('busy'); }
}

function renderTrendResults(items, query) {
  const root = $('trend-results');
  if (!items?.length) { root.innerHTML = '<div class="empty-state"><div class="empty-illustration">↗</div><h3>No matching recent videos found</h3><p>Try a broader search phrase or a longer upload window.</p></div>'; return; }
  root.innerHTML = items.map(item => {
    const views = numberCompact(item.viewCount); const rate = numberCompact(item.viewsPerHour);
    const thumbnail = item.thumbnail || '';
    return `<article class="trend-card"><div class="trend-thumb">${thumbnail ? `<img loading="lazy" src="${escapeAttribute(thumbnail)}" alt="Video thumbnail">` : ''}<span>${formatDuration(item.durationSeconds)}</span></div><div class="trend-body"><h4>${safeText(item.title)}</h4><div class="trend-channel">${safeText(item.channelTitle || 'YouTube creator')} · ${safeText(item.publishedLabel || '')}</div><div class="trend-metrics"><span class="metric">${views} views</span><span class="metric highlight">${rate}/h</span><span class="metric">${item.shortCandidate ? 'Short candidate' : 'Video'}</span></div><div class="trend-link-row"><a href="${escapeAttribute(item.url)}" target="_blank" rel="noopener noreferrer">Watch source ↗</a><button class="use-trend" data-title="${escapeAttribute(item.title)}" data-query="${escapeAttribute(query)}">Use as inspiration →</button></div></div></article>`;
  }).join('');
}
function numberCompact(value) { return Intl.NumberFormat('en', { notation: Number(value) >= 1000 ? 'compact' : 'standard', maximumFractionDigits: 1 }).format(Number(value) || 0); }
function formatDuration(seconds) { const m = Math.floor((seconds || 0) / 60); const s = Math.floor(seconds || 0) % 60; return `${m}:${String(s).padStart(2, '0')}`; }
async function searchTrends() {
  const query = $('trend-query').value.trim() || 'funny animation shorts', region = $('trend-region').value, hours = $('trend-period').value;
  const button = $('search-trends'); button.disabled = true; button.textContent = 'Scanning…';
  $('trend-results-title').textContent = 'Scanning recent uploads…'; $('trend-results-subtitle').textContent = 'Checking public video statistics. This usually takes a few seconds.';
  $('trend-results').innerHTML = '<div class="empty-state"><div class="empty-illustration">↗</div><h3>Searching YouTube</h3><p>Gathering recent video candidates and calculating views per hour.</p></div>';
  try {
    const response = await fetch(`${FUNCTION_ROOT}/trend-radar?q=${encodeURIComponent(query)}&region=${encodeURIComponent(region)}&hours=${encodeURIComponent(hours)}`, { headers: apiHeaders() });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Trend lookup failed (${response.status}).`);
    renderTrendResults(data.items, query); $('trend-results-title').textContent = `${data.items.length} recent video candidate${data.items.length === 1 ? '' : 's'}`;
    $('trend-results-subtitle').textContent = `Query: “${query}” · ${data.region || region} · ${data.windowLabel || `${hours} hour(s)`} · Ranked by calculated views/hour`;
    if (data.items.length) toast('Trend radar updated. Open the source links to check context before using a trend.');
  } catch (error) {
    $('trend-results-title').textContent = 'Trend search needs setup'; $('trend-results-subtitle').textContent = error.message;
    $('trend-results').innerHTML = `<div class="empty-state"><div class="empty-illustration">!</div><h3>Could not load live trend results</h3><p>${safeText(error.message)}</p><button class="btn btn-secondary" data-go="help">Open setup help</button></div>`;
    toast(error.message, 'error');
  } finally { button.disabled = false; button.textContent = '↗ Find videos'; }
}

async function checkConnections() {
  try {
    const response = await fetch(`${FUNCTION_ROOT}/health`, { headers: apiHeaders() }); const data = await response.json();
    if (data.accessCodeRequired && !data.authorized) {
      ['gemini-status','setup-gemini','youtube-status','setup-youtube'].forEach(id => { if ($(id)) { $(id).textContent = 'Access code needed'; $(id).className = 'chip chip-warn'; } });
      $('access-status').textContent = 'This site requires the Netlify STUDIO_ACCESS_CODE. Enter the matching code and tap “Use code for this tab”.'; return;
    }
    $('access-status').textContent = data.accessCodeRequired ? 'Access code accepted for this tab. The server will check it for provider requests.' : 'No shared access-code gate is active on this site. Configure STUDIO_ACCESS_CODE in Netlify before sharing a public URL.';
    setConnectionChip('gemini-status', data.geminiKeyPresent); setConnectionChip('setup-gemini', data.geminiKeyPresent);
    setConnectionChip('youtube-status', data.youtubeKeyPresent); setConnectionChip('setup-youtube', data.youtubeKeyPresent);
  } catch {
    ['gemini-status', 'setup-gemini', 'youtube-status', 'setup-youtube'].forEach(id => { if ($(id)) { $(id).textContent = 'Deploy functions'; $(id).className = 'chip chip-warn'; } });
  }
}
function setConnectionChip(id, present) { const el = $(id); if (!el) return; el.textContent = present ? 'Key present' : 'Not connected'; el.className = present ? 'chip connection-good' : 'chip connection-bad'; }

async function renderProjectList() {
  try { state.projects = await allProjects(); } catch { state.projects = []; }
  const root = $('project-list'); if (!root) return;
  if (!state.projects.length) { root.innerHTML = '<div class="empty-small">No saved projects yet. Create a story to start your first project.</div>'; return; }
  root.innerHTML = state.projects.map(project => `<div class="project-entry"><div class="project-thumb">⚡</div><div><strong>${safeText(project.title || project.name || 'Untitled project')}</strong><small>${(project.scenes || []).length} scenes · Saved ${new Date(project.updatedAt || Date.now()).toLocaleDateString()}</small></div><button class="btn btn-secondary" data-action="open-project" data-project="${escapeAttribute(project.id)}">Open</button><button class="btn btn-secondary" data-action="delete-project" data-project="${escapeAttribute(project.id)}">Delete</button></div>`).join('');
}
async function openProject(id) {
  try {
    const raw = state.db ? await dbRequest('readonly', store => store.get(id)) : (await allProjects()).find(p => p.id === id);
    if (!raw) throw new Error('That saved project could not be found.');
    state.project = hydrateProject(raw); state.directBlob = raw.directBlob instanceof Blob ? raw.directBlob : null;
    state.directBlobUrl = state.directBlob ? objectUrl(state.directBlob) : null;
    updateInputsFromProject(); await persistProject(state.project, true); setView('home'); toast(`Opened “${state.project.title || state.project.name}”.`);
  } catch (error) { toast(error.message, 'error'); }
}
async function createNewProject() {
  if (state.project) await persistProject(state.project, true);
  state.project = makeProject(); state.directBlob = null; state.directBlobUrl = null;
  updateInputsFromProject(); $('direct-prompt').value = ''; $('direct-stage').innerHTML = '<div class="stage-placeholder"><div class="play-orb">▶</div><strong>Nothing generated yet</strong><small>Your preview appears here after the provider returns a result.</small></div>';
  $('direct-download').hidden = true; $('direct-to-export').disabled = true; $('direct-progress-wrap').hidden = true;
  await persistProject(state.project, true); setView('story'); $('story-idea').focus(); toast('New project created. Start with your story idea.');
}
function downloadBlob(blob, filename) {
  if (!(blob instanceof Blob)) { toast('No downloadable file is available yet.', 'error'); return; }
  const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 12000);
}
function dataUrlToBlob(dataUrl) {
  if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:')) return null;
  const [header, data] = dataUrl.split(','); const mime = header.match(/^data:([^;]+)/)?.[1] || 'application/octet-stream';
  const bytes = atob(data); const array = new Uint8Array(bytes.length); for (let i = 0; i < bytes.length; i++) array[i] = bytes.charCodeAt(i);
  return new Blob([array], { type: mime });
}
function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = () => reject(reader.error || new Error('Could not export media')); reader.readAsDataURL(blob); });
}
async function exportProjectJson() {
  const p = state.project; if (!p) return;
  try {
    const out = projectForStorage(p); out.exportVersion = 1;
    if (out.directBlob instanceof Blob) { out.directBlobData = await blobToDataUrl(out.directBlob); out.directBlob = null; }
    for (let i = 0; i < out.scenes.length; i++) {
      if (out.scenes[i].clipBlob instanceof Blob) { out.scenes[i].clipBlobData = await blobToDataUrl(out.scenes[i].clipBlob); out.scenes[i].clipBlob = null; }
    }
    const blob = new Blob([JSON.stringify(out, null, 2)], { type: 'application/json' });
    downloadBlob(blob, `${(p.title || 'stickzap-project').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')}.json`);
    toast('Project backup exported. Keep it somewhere safe.');
  } catch (error) { toast(`Could not export project: ${error.message}`, 'error'); }
}
async function importProjectFile(file) {
  try {
    const value = JSON.parse(await file.text());
    if (!value || typeof value !== 'object' || !Array.isArray(value.scenes)) throw new Error('This does not look like a StickZap project backup.');
    if (value.directBlobData) { value.directBlob = dataUrlToBlob(value.directBlobData); delete value.directBlobData; }
    value.scenes = value.scenes.map((scene, i) => {
      if (scene.clipBlobData) { scene.clipBlob = dataUrlToBlob(scene.clipBlobData); delete scene.clipBlobData; }
      return normalizeScene(scene, i, value);
    });
    value.id = uid(); value.name = `${value.title || value.name || 'Imported project'} (imported)`; value.updatedAt = new Date().toISOString();
    state.project = hydrateProject(value); state.directBlob = value.directBlob instanceof Blob ? value.directBlob : null; state.directBlobUrl = state.directBlob ? objectUrl(state.directBlob) : null;
    await persistProject(state.project, true); updateInputsFromProject(); renderProjectList(); toast('Project imported and saved on this device.');
  } catch (error) { toast(`Import failed: ${error.message}`, 'error'); }
}
function sleepDraw(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
async function renderFinalSequence() {
  const clips = (state.project?.scenes || []).filter(s => s.clipBlob instanceof Blob);
  if (!clips.length) { toast('Generate at least one scene clip first.', 'error'); return; }
  if (!('MediaRecorder' in window) || !HTMLCanvasElement.prototype.captureStream) { toast('This browser cannot render a combined video. Download individual MP4 clips instead.', 'error'); return; }
  const ratio = state.project.frameRatio || '9:16'; let width = 720, height = 1280;
  if (ratio === '16:9') { width = 1280; height = 720; } else if (ratio === '1:1') { width = 960; height = 960; }
  const canvas = document.createElement('canvas'); canvas.width = width; canvas.height = height;
  const ctx = canvas.getContext('2d', { alpha: false }); const canvasStream = canvas.captureStream(30);
  let audioContext, audioDestination, video, recorder, chunks = [];
  setButtonBusy('render-final', true, 'Rendering…'); $('render-status').textContent = 'Rendering scene clips…'; $('render-substatus').textContent = `0 / ${clips.length} clips`; $('final-download').hidden = true;
  try {
    audioContext = new (window.AudioContext || window.webkitAudioContext)(); await audioContext.resume();
    audioDestination = audioContext.createMediaStreamDestination();
    video = document.createElement('video'); video.playsInline = true; video.preload = 'auto'; video.muted = false; video.style.position = 'fixed'; video.style.left = '-9999px'; document.body.appendChild(video);
    const source = audioContext.createMediaElementSource(video); source.connect(audioDestination);
    const tracks = [...canvasStream.getVideoTracks(), ...audioDestination.stream.getAudioTracks()];
    const outStream = new MediaStream(tracks);
    const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus') ? 'video/webm;codecs=vp9,opus' : MediaRecorder.isTypeSupported('video/webm;codecs=vp8,opus') ? 'video/webm;codecs=vp8,opus' : 'video/webm';
    recorder = new MediaRecorder(outStream, { mimeType }); recorder.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
    const stopped = new Promise((resolve, reject) => { recorder.onstop = resolve; recorder.onerror = e => reject(e.error || new Error('Render recorder failed')); });
    recorder.start(500);
    let currentIndex = 0, rafId;
    let drawing = true;
    const drawLoop = () => {
      if (!drawing) return;
      ctx.fillStyle = '#08090b'; ctx.fillRect(0, 0, width, height);
      if (video.readyState >= 2 && video.videoWidth && video.videoHeight) {
        const scale = Math.min(width / video.videoWidth, height / video.videoHeight);
        const dw = video.videoWidth * scale, dh = video.videoHeight * scale;
        ctx.drawImage(video, (width - dw) / 2, (height - dh) / 2, dw, dh);
        const caption = String(clips[currentIndex]?.voiceover || clips[currentIndex]?.dialogue || '').trim();
        if (caption) drawCaption(ctx, caption, width, height);
      }
      rafId = requestAnimationFrame(drawLoop);
    };
    drawLoop();
    for (let i = 0; i < clips.length; i++) {
      currentIndex = i; $('render-substatus').textContent = `${i + 1} / ${clips.length} clips · ${clips[i].title}`;
      video.src = objectUrl(clips[i].clipBlob); video.load();
      await new Promise((resolve, reject) => {
        const timeout = setTimeout(() => reject(new Error(`Could not load scene ${i + 1} for rendering.`)), 30000);
        const onCanPlay = () => { clearTimeout(timeout); video.removeEventListener('error', onError); resolve(); };
        const onError = () => { clearTimeout(timeout); video.removeEventListener('canplay', onCanPlay); reject(new Error(`Scene ${i + 1} video could not be opened by the browser.`)); };
        video.addEventListener('canplay', onCanPlay, { once: true }); video.addEventListener('error', onError, { once: true });
      });
      await new Promise((resolve, reject) => {
        video.onended = resolve;
        video.onerror = () => reject(new Error(`Scene ${i + 1} stopped during render.`));
        const playPromise = video.play();
        if (playPromise && typeof playPromise.catch === 'function') playPromise.catch(reject);
      });
      await sleepDraw(250);
    }
    drawing = false; cancelAnimationFrame(rafId); recorder.stop(); await stopped;
    const blob = new Blob(chunks, { type: recorder.mimeType || 'video/webm' });
    if (!blob.size) throw new Error('The browser produced an empty video file.');
    state.renderBlob = blob; state.renderUrl = objectUrl(blob); $('final-download').href = state.renderUrl; $('final-download').hidden = false;
    $('render-status').textContent = 'Final sequence ready'; $('render-substatus').textContent = `${clips.length} clips · ${(blob.size / (1024 * 1024)).toFixed(1)} MB · WebM format`;
    toast('Final sequence rendered on your device. Download the WebM file.');
  } catch (error) {
    if (recorder && recorder.state !== 'inactive') try { recorder.stop(); } catch {}
    $('render-status').textContent = 'Render did not complete'; $('render-substatus').textContent = error.message; toast(error.message, 'error');
  } finally {
    if (video) { video.pause(); video.removeAttribute('src'); video.load(); video.remove(); }
    if (audioContext) try { await audioContext.close(); } catch {}
    setButtonBusy('render-final', false);
  }
}
function drawCaption(ctx, text, width, height) {
  ctx.save(); ctx.font = `bold ${Math.max(18, Math.round(width * .024))}px Manrope, sans-serif`;
  const maxTextWidth = width * .84, words = text.split(/\s+/); let lines = [], line = '';
  for (const word of words) { const candidate = line ? `${line} ${word}` : word; if (ctx.measureText(candidate).width > maxTextWidth && line) { lines.push(line); line = word; } else line = candidate; }
  if (line) lines.push(line); lines = lines.slice(0, 3);
  const lineHeight = Math.max(24, width * .033), boxHeight = lines.length * lineHeight + 28, y = Math.round(height * .73);
  ctx.fillStyle = 'rgba(0,0,0,.72)'; ctx.beginPath(); roundRect(ctx, width * .07, y, width * .86, boxHeight, 15); ctx.fill();
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#ffffff';
  lines.forEach((txt, i) => ctx.fillText(txt, width / 2, y + 14 + (i + .5) * lineHeight, maxTextWidth)); ctx.restore();
}
function roundRect(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r); ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h); ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r); ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.closePath(); }

function downloadSceneAsset(action, index, frameType) {
  const scene = state.project?.scenes?.[index]; if (!scene) return;
  if (action === 'download-frame') {
    const data = frameType === 'start' ? scene.startFrame : scene.endFrame; if (!data) return;
    downloadBlob(dataUrlToBlob(data), `stickzap-scene-${index + 1}-${frameType}.jpg`);
  } else if (action === 'download-clip') {
    if (!scene.clipBlob) return; downloadBlob(scene.clipBlob, `stickzap-scene-${index + 1}.mp4`);
  }
}
async function downloadAllClips() {
  const clips = (state.project?.scenes || []).filter(s => s.clipBlob instanceof Blob);
  if (!clips.length) { toast('No generated scene clips to download yet.', 'error'); return; }
  for (let i = 0; i < clips.length; i++) { downloadBlob(clips[i].clipBlob, `stickzap-scene-${i + 1}.mp4`); await delay(400); }
  toast(`Started ${clips.length} scene download(s). Your browser may ask permission for multiple downloads.`);
}
async function addDirectToScenes() {
  if (!(state.project?.directBlob instanceof Blob)) { toast('Generate a direct video clip first.', 'error'); return; }
  const p = state.project;
  const scene = normalizeScene({ title: 'Direct generated clip', action: p.script || p.idea, videoPrompt: $('direct-prompt').value, clipBlob: p.directBlob, duration: Number($('direct-duration').value) || 8 }, p.scenes.length, p);
  scene.clipBlob = p.directBlob; scene.clipUrl = objectUrl(p.directBlob); p.scenes.push(scene); p.sceneCount = p.scenes.length;
  await persistProject(p, true); renderScenes(); updateHomeStats(); setView('frames'); toast('Direct video added to the scene list.');
}

async function init() {
  try { state.db = await openDB(); } catch { state.db = null; }
  try {
    state.projects = await allProjects();
    if (state.projects.length) state.project = hydrateProject(state.projects[0]);
  } catch {}
  if (!state.project) state.project = makeProject();
  if (state.project.directBlob instanceof Blob) { state.directBlob = state.project.directBlob; state.directBlobUrl = objectUrl(state.directBlob); }
  updateInputsFromProject(); await persistProject(state.project, true); await renderProjectList(); checkConnections();
  const hash = location.hash.replace('#', ''); if (VIEWS[hash]) setView(hash);
  $('local-outline').addEventListener('click', () => generateStory(false));
  $('generate-story').addEventListener('click', () => generateStory(true));
  $('story-idea').addEventListener('input', () => { syncInputsToProject(); scheduleSave(); });
  ['story-genre','story-audience','story-language','scene-count','story-length','visual-style','character-lock','frame-ratio','direct-ratio','social-caption','social-tags'].forEach(id => {
    $(id).addEventListener('change', () => { syncInputsToProject(); scheduleSave(); });
    if (['character-lock','social-caption','social-tags'].includes(id)) $(id).addEventListener('input', () => { syncInputsToProject(); scheduleSave(); });
  });
  $('use-story-direct').addEventListener('click', () => { $('direct-prompt').value = `${state.project.hook}\n\nFull story: ${state.project.script || state.project.idea}\n\nVisual style: ${state.project.visualStyle}. Character: ${state.project.characterLock}.` .trim(); setView('direct'); });
  $('use-story-prompt').addEventListener('click', () => { const p = state.project; $('direct-prompt').value = `${p.hook}\n\n${p.script || p.idea}\n\n${p.visualStyle}. Character consistency: ${p.characterLock}. Create a complete short cartoon with a strong opening, clear action, and a funny ending.`.trim(); toast('Current story inserted into the video prompt.'); });
  $('open-frame-studio').addEventListener('click', () => setView('frames'));
  $('split-current-story').addEventListener('click', () => { if (!state.project.idea && !state.project.script) { toast('Generate or write a story first.', 'error'); return; } if (state.project.scenes.some(scene => scene.startFrame || scene.endFrame || scene.clipBlob) && !confirm('Rebuilding scenes will replace the current scene cards and their attached media. Continue?')) return; const result = localStoryDraft('script'); applyStoryResult(result, 'Scenes rebuilt locally from the current script. Review and edit each scene.'); setView('frames'); });
  $('generate-all-frames').addEventListener('click', generateAllFrames);
  $('generate-full-animation').addEventListener('click', generateFullAnimation);
  $('generate-direct').addEventListener('click', generateDirectVideo);
  $('direct-duration').addEventListener('change', () => { if ($('direct-duration').value !== '8' && $('direct-resolution').value === '1080p') $('direct-resolution').value = '720p'; });
  $('direct-resolution').addEventListener('change', () => { if ($('direct-resolution').value === '1080p') $('direct-duration').value = '8'; });
  $('direct-to-export').addEventListener('click', addDirectToScenes);
  $('search-trends').addEventListener('click', searchTrends);
  $('refresh-projects').addEventListener('click', renderProjectList);
  $('export-project').addEventListener('click', exportProjectJson);
  $('import-project').addEventListener('change', async e => { if (e.target.files?.[0]) await importProjectFile(e.target.files[0]); e.target.value = ''; });
  $('render-final').addEventListener('click', renderFinalSequence);
  $('download-all-clips').addEventListener('click', downloadAllClips);
  $('copy-social').addEventListener('click', async () => { const text = `${$('social-caption').value.trim()}\n\n${$('social-tags').value.trim()}`.trim(); try { await navigator.clipboard.writeText(text); toast('Caption and hashtags copied.'); } catch { const t = document.createElement('textarea'); t.value = text; document.body.appendChild(t); t.select(); document.execCommand('copy'); t.remove(); toast('Caption and hashtags copied.'); } });
  $('new-project').addEventListener('click', createNewProject);
  $('mobile-menu').addEventListener('click', () => $('sidebar').classList.toggle('open'));
  $('check-connections').addEventListener('click', checkConnections);
  $('save-access-code').addEventListener('click', async () => { const code = $('access-code').value.trim(); if (!code) { toast('Enter the access code first.', 'error'); return; } try { sessionStorage.setItem('stickzap-access-code', code); } catch {} await checkConnections(); toast('Access code saved for this browser tab.'); });
  $('clear-access-code').addEventListener('click', async () => { try { sessionStorage.removeItem('stickzap-access-code'); } catch {} $('access-code').value = ''; await checkConnections(); toast('Access code cleared for this tab.'); });
  document.addEventListener('click', async event => {
    const viewButton = event.target.closest('[data-view]'); if (viewButton) { setView(viewButton.dataset.view); return; }
    const goButton = event.target.closest('[data-go]'); if (goButton) { setView(goButton.dataset.go); return; }
    const actionButton = event.target.closest('[data-action]');
    if (actionButton) {
      const action = actionButton.dataset.action;
      if (action === 'start-frame' || action === 'end-frame') { const type = action === 'start-frame' ? 'start' : 'end'; await generateFrame(Number(actionButton.dataset.scene), type).catch(() => {}); }
      if (action === 'animate-scene') await animateScene(Number(actionButton.dataset.scene));
      if (action === 'download-frame' || action === 'download-clip') downloadSceneAsset(action, Number(actionButton.dataset.scene), actionButton.dataset.frame);
      if (action === 'open-project') await openProject(actionButton.dataset.project);
      if (action === 'delete-project') {
        const id = actionButton.dataset.project; if (!confirm('Delete this saved project from this device? This cannot be undone unless you have a backup.')) return;
        if (state.db) await dbRequest('readwrite', store => store.delete(id)); else { const list = (await allProjects()).filter(p => p.id !== id); localStorage.setItem('stickzap-projects', JSON.stringify(list)); }
        if (state.project.id === id) { state.project = makeProject(); await persistProject(state.project, true); updateInputsFromProject(); }
        await renderProjectList(); toast('Project deleted from local storage.');
      }
      return;
    }
    const trendButton = event.target.closest('.use-trend');
    if (trendButton) {
      const title = trendButton.dataset.title; $('story-idea').value = `Create a completely original funny 2D cartoon inspired by the broad format or audience appeal of this public video: “${title}”. Do not copy its characters, dialogue, script, or visuals. Create a fresh premise and unexpected punchline.`;
      syncInputsToProject(); scheduleSave(); setView('story'); $('story-idea').focus(); toast('Added an original-story brief inspired by the broad trend format.');
    }
  });
  document.addEventListener('input', event => {
    const target = event.target;
    if (target.matches('[data-scene-field]')) {
      const scene = state.project.scenes[Number(target.dataset.scene)]; if (!scene) return;
      scene[target.dataset.sceneField] = target.value; scheduleSave();
    } else if (target.matches('[data-scene-title]')) {
      const scene = state.project.scenes[Number(target.dataset.sceneTitle)]; if (!scene) return;
      scene.title = target.value; scheduleSave();
    }
  });
  document.addEventListener('change', event => {
    const target = event.target;
    if (target.matches('[data-scene-field]')) persistProject(state.project, true);
    if (target.matches('[data-scene-title]')) { const scene = state.project.scenes[Number(target.dataset.sceneTitle)]; if (scene) scene.title = target.value; persistProject(state.project, true); }
  });
  window.addEventListener('beforeunload', () => { if (state.project && state.db) { try { const tx = state.db.transaction('projects', 'readwrite'); tx.objectStore('projects').put(projectForStorage(state.project)); } catch {} } });
  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('/service-worker.js').catch(() => {});
}

init().catch(error => { console.error(error); toast('The app opened but local project storage could not initialize. Try reloading this page.', 'error'); });
