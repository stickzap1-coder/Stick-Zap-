export function denyIfUnauthorized(request) {
  const expected = process.env.STUDIO_ACCESS_CODE;
  if (!expected) return null;
  const supplied = request.headers.get('x-studio-access-code') || '';
  if (supplied.length > 160 || supplied !== expected) {
    return Response.json({ error: 'This workspace is protected. Open Setup & Help and enter the private access code configured for this Netlify site.' }, { status: 401, headers: { 'cache-control': 'no-store' } });
  }
  return null;
}
