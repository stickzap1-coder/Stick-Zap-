import { denyIfUnauthorized } from '../utils/auth.mjs';
const json = (body, status = 200) => Response.json(body, { status, headers: { 'cache-control': 'no-store' } });
function parseDuration(iso) {
  const match = String(iso || '').match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  return match ? Number(match[1] || 0) * 3600 + Number(match[2] || 0) * 60 + Number(match[3] || 0) : 0;
}
function labelAge(date) {
  const hours = Math.max(1, Math.round((Date.now() - Date.parse(date)) / 3600000));
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24); return `${days}d ago`;
}
export default async function handler(request) {
  if (request.method !== 'GET') return json({ error: 'Use GET.' }, 405);
  const denied = denyIfUnauthorized(request); if (denied) return denied;
  const key = process.env.YOUTUBE_API_KEY;
  if (!key) return json({ error: 'Live trend search is not connected. Add YOUTUBE_API_KEY in Netlify environment variables. You can still search YouTube manually in a browser.' }, 503);
  const url = new URL(request.url);
  const q = (url.searchParams.get('q') || 'funny animation shorts').trim().slice(0, 100);
  const region = /^[A-Z]{2}$/.test((url.searchParams.get('region') || 'US').toUpperCase()) ? (url.searchParams.get('region') || 'US').toUpperCase() : 'US';
  const allowedHours = [24, 168, 720]; const hours = allowedHours.includes(Number(url.searchParams.get('hours'))) ? Number(url.searchParams.get('hours')) : 168;
  const publishedAfter = new Date(Date.now() - hours * 3600000).toISOString();
  const api = async (endpoint, params) => {
    const u = new URL(`https://www.googleapis.com/youtube/v3/${endpoint}`);
    Object.entries({ ...params, key }).forEach(([k, v]) => u.searchParams.set(k, String(v)));
    const response = await fetch(u.toString()); const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error?.message || `YouTube API ${response.status}`);
    return data;
  };
  try {
    const search = await api('search', { part: 'snippet', type: 'video', order: 'viewCount', maxResults: 25, publishedAfter, regionCode: region, safeSearch: 'moderate', q });
    const ids = (search.items || []).map(item => item.id?.videoId).filter(Boolean);
    if (!ids.length) return json({ items: [], region, windowLabel: hours === 24 ? 'last 24 hours' : hours === 168 ? 'last 7 days' : 'last 30 days', query: q });
    const details = await api('videos', { part: 'snippet,statistics,contentDetails', id: ids.join(',') });
    const items = (details.items || []).map(item => {
      const publishedAt = item.snippet?.publishedAt || new Date().toISOString();
      const viewCount = Number(item.statistics?.viewCount || 0);
      const durationSeconds = parseDuration(item.contentDetails?.duration);
      const ageHours = Math.max(1, (Date.now() - Date.parse(publishedAt)) / 3600000);
      const thumbs = item.snippet?.thumbnails || {};
      const thumbnail = thumbs.high?.url || thumbs.medium?.url || thumbs.default?.url || '';
      return {
        id: item.id, title: item.snippet?.title || 'Untitled video', channelTitle: item.snippet?.channelTitle || '', publishedAt,
        publishedLabel: labelAge(publishedAt), viewCount, viewsPerHour: Math.round(viewCount / ageHours), durationSeconds,
        shortCandidate: durationSeconds <= 180, thumbnail, url: `https://www.youtube.com/watch?v=${encodeURIComponent(item.id)}`,
        description: String(item.snippet?.description || '').slice(0, 260)
      };
    }).filter(item => item.durationSeconds <= 180).sort((a, b) => b.viewsPerHour - a.viewsPerHour).slice(0, 20);
    return json({ items, region, query: q, hours, windowLabel: hours === 24 ? 'last 24 hours' : hours === 168 ? 'last 7 days' : 'last 30 days', rankMethod: 'public views divided by hours since upload; not a guaranteed virality score', caveat: 'YouTube Data API does not reliably expose the official Shorts designation or video aspect ratio.' });
  } catch (error) {
    return json({ error: `YouTube trend lookup failed: ${error.message}. Verify YOUTUBE_API_KEY, YouTube Data API v3, quota and restrictions.` }, 502);
  }
}
