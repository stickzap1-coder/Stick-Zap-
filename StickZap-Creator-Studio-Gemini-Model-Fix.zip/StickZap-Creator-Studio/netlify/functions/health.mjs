export default async function handler(request) {
  const expected = process.env.STUDIO_ACCESS_CODE;
  const supplied = request.headers.get('x-studio-access-code') || '';
  const accessCodeRequired = Boolean(expected);
  const authorized = !accessCodeRequired || (supplied.length <= 160 && supplied === expected);
  if (!authorized) return Response.json({ accessCodeRequired, authorized: false, geminiKeyPresent: null, youtubeKeyPresent: null, note: 'Enter the private access code configured for this Netlify site.' }, { headers: { 'cache-control': 'no-store' } });
  return Response.json({
    accessCodeRequired, authorized: true,
    geminiKeyPresent: Boolean(process.env.GEMINI_API_KEY),
    youtubeKeyPresent: Boolean(process.env.YOUTUBE_API_KEY),
    note: 'Key presence is checked only. It does not verify quota, billing, API permissions, or model access.'
  }, { headers: { 'cache-control': 'no-store' } });
}
