import { denyIfUnauthorized } from '../utils/auth.mjs';
const json = (body, status = 200) => Response.json(body, { status, headers: { 'cache-control': 'no-store' } });
export default async function handler(request) {
  if (request.method !== 'GET') return json({ error: 'Use GET.' }, 405);
  const denied = denyIfUnauthorized(request); if (denied) return denied;
  const key = process.env.GEMINI_API_KEY;
  if (!key) return json({ error: 'Video generation is not connected. Add GEMINI_API_KEY in Netlify environment variables.' }, 503);
  const operation = new URL(request.url).searchParams.get('operation') || '';
  if (!/^(?:models\/[A-Za-z0-9._-]+\/)?operations\/[A-Za-z0-9._-]+$/.test(operation)) return json({ error: 'Invalid operation identifier.' }, 400);
  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/${operation}`, { headers: { 'x-goog-api-key': key } });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) return json({ error: data.error?.message || 'Could not read generation status.' }, response.status);
    const done = Boolean(data.done);
    const failure = data.error?.message || data.response?.generateVideoResponse?.raiMediaFilteredReasons?.join('; ');
    const sample = data.response?.generateVideoResponse?.generatedSamples?.[0] || data.response?.generatedVideos?.[0];
    const videoUri = sample?.video?.uri || sample?.videoUri;
    return json({ done, state: done ? (failure ? 'failed' : videoUri ? 'completed' : 'failed') : 'processing', error: failure || (!done ? undefined : !videoUri ? 'Generation completed but no video URI was returned.' : undefined), videoUri: videoUri || undefined, operationName: operation });
  } catch { return json({ error: 'Could not contact Google Veo for status.' }, 502); }
}
