import { denyIfUnauthorized } from '../utils/auth.mjs';
const json = (body, status = 200) => Response.json(body, { status, headers: { 'cache-control': 'no-store' } });

function parseImage(dataUrl, name) {
  if (!dataUrl) return null;
  if (typeof dataUrl !== 'string') throw new Error(`${name} must be a data URL.`);
  const match = dataUrl.match(/^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/);
  if (!match) throw new Error(`${name} must be a PNG, JPEG or WebP data URL.`);
  if (match[2].length > 3_000_000) throw new Error(`${name} is too large. Resize the image and try again.`);
  return { inlineData: { mimeType: match[1], data: match[2] } };
}

export default async function handler(request) {
  if (request.method !== 'POST') return json({ error: 'Use POST.' }, 405);
  const denied = denyIfUnauthorized(request); if (denied) return denied;
  const key = process.env.GEMINI_API_KEY;
  if (!key) return json({ error: 'Video generation is not connected. Add GEMINI_API_KEY in Netlify environment variables, then redeploy.' }, 503);
  let input;
  try { input = await request.json(); } catch { return json({ error: 'Invalid JSON request.' }, 400); }
  const prompt = typeof input.prompt === 'string' ? input.prompt.trim() : '';
  if (!prompt || prompt.length > 8000) return json({ error: 'Prompt is required and must be under 8,000 characters.' }, 400);
  const aspectRatio = ['9:16', '16:9'].includes(input.aspectRatio) ? input.aspectRatio : '9:16';
  const durationSeconds = ['4', '6', '8'].includes(String(input.durationSeconds)) ? String(input.durationSeconds) : '8';
  const resolution = ['720p', '1080p'].includes(input.resolution) ? input.resolution : '720p';
  if (resolution === '1080p' && durationSeconds !== '8') return json({ error: 'The selected Veo 3.1 endpoint currently requires an 8-second clip for 1080p. Choose 8 seconds or 720p.' }, 400);
  let instance = { prompt: `Create a polished animation with clear readable action, expressive poses, smooth motion, consistent character design, clean composition, and no watermarks. ${prompt}` };
  try {
    const first = parseImage(input.firstFrame, 'Start frame'); const last = parseImage(input.lastFrame, 'End frame');
    if (last && !first) return json({ error: 'An end frame can only be used with a start frame.' }, 400);
    if (first) instance.image = first;
    if (last) instance.lastFrame = last;
  } catch (error) { return json({ error: error.message }, 400); }
  try {
    const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/veo-3.1-generate-preview:predictLongRunning', {
      method: 'POST', headers: { 'x-goog-api-key': key, 'content-type': 'application/json' },
      body: JSON.stringify({ instances: [instance], parameters: { aspectRatio, durationSeconds, resolution, numberOfVideos: 1 } })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) return json({ error: data.error?.message || 'Google Veo request failed. Check model access, billing, quota, region and Netlify logs.' }, response.status);
    if (!data.name) return json({ error: 'Google did not return a generation operation.' }, 502);
    return json({ operationName: data.name, state: 'queued', model: 'veo-3.1-generate-preview', aspectRatio, durationSeconds, resolution }, 202);
  } catch {
    return json({ error: 'Could not contact Google Veo. Check network access and Netlify function logs.' }, 502);
  }
}
