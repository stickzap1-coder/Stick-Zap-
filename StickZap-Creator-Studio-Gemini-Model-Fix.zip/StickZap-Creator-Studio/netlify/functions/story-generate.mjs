import { denyIfUnauthorized } from '../utils/auth.mjs';
const json = (body, status = 200) => Response.json(body, { status, headers: { 'cache-control': 'no-store' } });

function parseJson(text) {
  const cleaned = String(text || '').trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  const first = cleaned.indexOf('{'); const last = cleaned.lastIndexOf('}');
  if (first < 0 || last < first) throw new Error('The story model did not return valid JSON. Try again.');
  return JSON.parse(cleaned.slice(first, last + 1));
}

export default async function handler(request) {
  if (request.method !== 'POST') return json({ error: 'Use POST.' }, 405);
  const denied = denyIfUnauthorized(request); if (denied) return denied;
  const key = process.env.GEMINI_API_KEY;
  if (!key) return json({ error: 'AI story generation is not connected yet. Add GEMINI_API_KEY in Netlify environment variables, then redeploy. Use “Quick local outline” while setting this up.' }, 503);
  let input;
  try { input = await request.json(); } catch { return json({ error: 'Request body must be valid JSON.' }, 400); }
  const idea = typeof input.idea === 'string' ? input.idea.trim() : '';
  if (!idea || idea.length > 6000) return json({ error: 'Enter a story idea under 6,000 characters.' }, 400);
  const sceneCount = Math.max(1, Math.min(12, Number.parseInt(input.sceneCount, 10) || 5));
  const allowed = (value, list, fallback) => list.includes(value) ? value : fallback;
  const genre = typeof input.genre === 'string' ? input.genre.slice(0, 100) : 'Funny daily life';
  const audience = allowed(input.audience, ['General audience', 'Family friendly', 'Kids', 'Teens'], 'General audience');
  const language = allowed(input.language, ['English', 'Bengali', 'Thai', 'Hindi'], 'English');
  const length = allowed(input.length, ['short', 'medium', 'long'], 'medium');
  const style = typeof input.style === 'string' ? input.style.slice(0, 120) : 'StickZap 2D cartoon';
  const characterLock = typeof input.characterLock === 'string' ? input.characterLock.slice(0, 900) : '';
  const prompt = `You are an expert short-form comedy writer and animation storyboard artist. Create an ORIGINAL story, not a copy of any existing creator's script or characters.

User idea/script: ${idea}
Genre: ${genre}
Target audience: ${audience}
Output language: ${language}
Length target: ${length}
Visual style: ${style}
Character consistency lock: ${characterLock || 'Create a memorable original cartoon character.'}
Required scene count: exactly ${sceneCount}

Create a hook-first, easy-to-follow story suitable for a funny short. Get to the premise quickly, escalate the problem, and finish with a clear payoff. Dialogue should be brief and speakable. Keep all content age-appropriate for the selected audience. Do not include camera instructions that contradict the scene action. Scene prompts should explicitly repeat character consistency details and describe a single visual moment.

Return ONLY valid JSON matching this shape:
{
 "title":"Short title",
 "hook":"1 short opening hook",
 "summary":"2 short sentences summarizing the story",
 "script":"Full story in ${language}, including concise dialogue and a clear ending",
 "scenes":[
  {"title":"Scene title","action":"What physically happens on screen","dialogue":"Brief dialogue or empty string","voiceover":"Optional narration or empty string","imagePrompt":"Detailed single still-image prompt, visual style and character consistency included","videoPrompt":"Action, movement, camera, timing, sound cues and ending beat for this clip"}
 ]
}
Return exactly ${sceneCount} scene objects. Output all prose in ${language}. Keep it original and specific. JSON only, no Markdown.`;
  try {
    const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent', {
      method: 'POST', headers: { 'x-goog-api-key': key, 'content-type': 'application/json' },
      body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { responseMimeType: 'application/json', temperature: 0.85, maxOutputTokens: 10000 } })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) return json({ error: data.error?.message || 'Gemini story request failed. Check model access, quota, billing, and Netlify logs.' }, response.status);
    const text = data.candidates?.[0]?.content?.parts?.map(part => part.text || '').join('\n') || '';
    let story;
    try { story = parseJson(text); } catch (error) { return json({ error: error.message }, 502); }
    if (!Array.isArray(story.scenes)) story.scenes = [];
    story.scenes = story.scenes.slice(0, sceneCount).map((scene, i) => ({
      title: String(scene.title || `Scene ${i + 1}`).slice(0, 160), action: String(scene.action || '').slice(0, 1800),
      dialogue: String(scene.dialogue || '').slice(0, 900), voiceover: String(scene.voiceover || '').slice(0, 900),
      imagePrompt: String(scene.imagePrompt || scene.action || '').slice(0, 3500), videoPrompt: String(scene.videoPrompt || scene.action || '').slice(0, 3500)
    }));
    if (!story.scenes.length) return json({ error: 'Gemini returned a story without scene details. Try again.' }, 502);
    return json({ title: String(story.title || 'Untitled funny short').slice(0, 180), hook: String(story.hook || '').slice(0, 500), summary: String(story.summary || '').slice(0, 1800), script: String(story.script || idea).slice(0, 10000), scenes: story.scenes, model: 'gemini-3.8-flash' });
  } catch {
    return json({ error: 'Could not contact Gemini. Check network access and Netlify function logs.' }, 502);
  }
}
