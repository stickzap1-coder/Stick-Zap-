import { denyIfUnauthorized } from '../utils/auth.mjs';
const allowedHosts = new Set(['generativelanguage.googleapis.com', 'storage.googleapis.com']);
export default async function handler(request) {
  if (request.method !== 'GET') return new Response('Use GET.', { status: 405 });
  const denied = denyIfUnauthorized(request); if (denied) return denied;
  const key = process.env.GEMINI_API_KEY;
  if (!key) return new Response('Video generation is not connected.', { status: 503 });
  const uri = new URL(request.url).searchParams.get('uri') || '';
  let parsed;
  try { parsed = new URL(uri); } catch { return new Response('Invalid video URI.', { status: 400 }); }
  if (parsed.protocol !== 'https:' || !allowedHosts.has(parsed.hostname)) return new Response('Video URI host is not allowed.', { status: 400 });
  try {
    const upstream = await fetch(parsed.toString(), { headers: { 'x-goog-api-key': key } });
    if (!upstream.ok || !upstream.body) return new Response('Google video download failed. Check API access and retry.', { status: upstream.status || 502 });
    const contentType = upstream.headers.get('content-type') || 'video/mp4';
    const headers = new Headers({ 'content-type': contentType, 'content-disposition': 'attachment; filename="stickzap-clip.mp4"', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' });
    const length = upstream.headers.get('content-length'); if (length) headers.set('content-length', length);
    return new Response(upstream.body, { status: 200, headers });
  } catch { return new Response('Video download failed. Try again and check Netlify function logs.', { status: 502 }); }
}
