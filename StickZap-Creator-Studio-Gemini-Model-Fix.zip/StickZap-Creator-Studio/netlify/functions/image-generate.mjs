import { denyIfUnauthorized } from '../utils/auth.mjs';
const json = (body, status = 200) => Response.json(body, { status, headers: { 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' } });

export default async function handler(request) {
  if (request.method !== 'POST') return json({ error: 'Use POST.' }, 405);
  const denied = denyIfUnauthorized(request); if (denied) return denied;
  const key = process.env.GEMINI_API_KEY;
  if (!key) return json({ error: 'Image generation is not connected. Add GEMINI_API_KEY in Netlify environment variables, then redeploy.' }, 503);
  let input;
  try { input = await request.json(); } catch { return json({ error: 'Invalid JSON request.' }, 400); }
  const prompt = typeof input.prompt === 'string' ? input.prompt.trim() : '';
  if (!prompt || prompt.length > 5000) return json({ error: 'Enter an image prompt under 5,000 characters.' }, 400);
  const style = typeof input.style === 'string' ? input.style.slice(0, 120) : 'StickZap hand-drawn 2D cartoon';
  const allowed = ['portrait 9:16', 'square 1:1', 'landscape 16:9'];
  const ratio = allowed.includes(input.ratio) ? input.ratio : 'portrait 9:16';
  const composition = ratio === 'portrait 9:16' ? 'vertical portrait, tall 9:16 frame' : ratio === 'square 1:1' ? 'square 1:1 frame' : 'landscape wide 16:9 frame';
  const fullPrompt = `Create one polished still illustration for an animation storyboard. Art direction: ${style}. Composition: ${composition}. Keep a clear focal subject, readable silhouette, coherent scene layout, strong consistent character design, and no watermark or written captions unless explicitly requested. Prompt: ${prompt}`;
  try {
    const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image:generateContent', {
      method: 'POST', headers: { 'x-goog-api-key': key, 'content-type': 'application/json' },
      body: JSON.stringify({ contents: [{ parts: [{ text: fullPrompt }] }], generationConfig: { responseModalities: ['TEXT', 'IMAGE'] } })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) return json({ error: data.error?.message || 'Google image generation failed. Check model access, quota, billing, and Netlify logs.' }, response.status);
    const parts = data.candidates?.flatMap(candidate => candidate.content?.parts || []) || [];
    const imagePart = parts.find(part => part.inlineData?.data && String(part.inlineData?.mimeType || '').startsWith('image/'));
    if (!imagePart) return json({ error: 'Google returned no image. Try another prompt or verify image-model access.' }, 502);
    return json({ mimeType: imagePart.inlineData.mimeType, imageData: imagePart.inlineData.data, text: parts.find(part => part.text)?.text || '' });
  } catch {
    return json({ error: 'Could not contact Google image generation. Check network access and Netlify function logs.' }, 502);
  }
}
